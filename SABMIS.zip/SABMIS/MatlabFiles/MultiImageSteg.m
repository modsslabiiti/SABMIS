    clc 
    clear all
    time_start_em1 = tic;%    tic;
%%%% Cover Image %%%%%
    Cover_Image_Original=imread('tulips.png');
    [r, c, h] = size(Cover_Image_Original);
    if h>1
        Cover_Image_Original = rgb2gray(Cover_Image_Original);
        %Cover_Image_Original = Cover_Image_Original(:,:,1);
    end
    Cover_Image_Original = imresize(Cover_Image_Original,[1024 1024]);
%%%%%% Sampling %%%%%%%
[CI1, CI2, CI3, CI4] = ImageSampling(Cover_Image_Original);
%%%%%%%%%%%%%%%%%EMbedding in one sub-image of%%%%%%%%%%%%%
Cover_Image = CI1; % 512x512
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [row_Cover,col_Cover]=size(Cover_Image);
    blk_Cover=8;
    nBlk_Cover=(row_Cover*col_Cover)/(blk_Cover*blk_Cover);
    BlkSize_Cover = blk_Cover*blk_Cover;
    order=[1 9 2 3 10 17 25 18 11 4 5 12 19 26 33 41 34 27 20 13 6 7 14 21 28 35 42 49 57 50 43 36 29 22 15 8 16 23 30 37 44 51 58 59 52 45 38 31 24 32 39 46 53 60 61 54 47 40 48 55 62 63 56 64];
    cof_Cover = 32;  % 32
    cof_Secret = 32;  % 16
 %%%%% DCT Function %%%%%%
   fun1=@dct2;
   fun2=@idct2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % block wise DCT on Cover Image
   J_Cover = blkproc(Cover_Image,[blk_Cover blk_Cover],fun1);
   x_Cover = im2col(J_Cover,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
   
   x_Cover_not_embed = x_Cover(order(1:cof_Cover),:);
   x_Cover_can_embed = x_Cover(order(cof_Cover+1:BlkSize_Cover),:);
   
   %%%%%%%%%%%% Matrix for Cover Image %%%%%%%%%%%%%%%%%%%%
   n_col = BlkSize_Cover - cof_Cover;
   n_row = 50*n_col; %nCover_Sample = blk_Cover*blk_Cover; ALso try 
   A_Cover = randn(n_row,n_col);
    % normalization
   A_Cover_normalize=normc(A_Cover);
 %%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Cover(:,i)=A_Cover_normalize*x_Cover_can_embed(:,i);
end
y_Cover_update = zeros(cof_Cover+n_row, nBlk_Cover); 
y_Cover_update = [x_Cover_not_embed; y_Cover];   % row wise concatenate

 %%%% Secret Image %%%%%
    Secret_Image_Resize=imread('lake.tif');
    [r1, c1, h1] = size(Secret_Image_Resize);
    if h1>1
        Secret_Image_Resize = Secret_Image_Resize(:,:,1);
    end
 Secret_Image_Resize = imresize(Secret_Image_Resize,[512 512]);
    [row_Secret,col_Secret]=size(Secret_Image_Resize);
    blk_Secret=8;
    nBlk_Secret=(row_Secret*col_Secret)/(blk_Secret*blk_Secret);
    BlkSize_Secret=blk_Secret*blk_Secret;
    J_Secret = blkproc(Secret_Image_Resize,[blk_Secret blk_Secret],fun1);
    x_Secret=im2col(J_Secret,[blk_Secret blk_Secret],'distinct');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Embedding of secret message----------
alpha = 0.01;%0.01
beta = 0.1;%0.01
gama = 1;
x_Secret_zig = x_Secret(order,:);
x_Secret_Reduced = x_Secret_zig(1:cof_Secret,:);
y_Cover_Reduced = y_Cover_update;
for i=1:nBlk_Cover

    temp1 = 6;  % temp1 = 1 for Trial7.m
    temp2 = 2*temp1;
    y_Cover_Reduced(cof_Cover,i)= y_Cover_Reduced(cof_Cover-temp2,i)+ alpha*x_Secret_Reduced(1,i);%DC coefficient

    y_Cover_Reduced(cof_Cover-temp1+1:cof_Cover-1,i)= y_Cover_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i)+ beta*x_Secret_Reduced(2:temp1,i); 
    temp = cof_Secret - 1; %temp = 15;
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp -(temp1 - 1);

   y_Cover_Reduced(t1:t2,i) = y_Cover_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i) + gama * x_Secret_Reduced((temp1-1)+2:cof_Secret,i);  
end
time_end_em1 = toc(time_start_em1);

time_start_st1 = tic;
%%%%%%%%% Stego Image Recover from samples %%%%%%%%
%%%%%separate  real coefficients and measurements from y_Cover_Reduced
y_Cover_Recover_real = y_Cover_Reduced(1:cof_Cover,:);       % 8 is size of ordr_not_embed
for i=1:(row_Cover*col_Cover)/(blk_Cover*blk_Cover)
  y_Cover_temp = y_Cover_Reduced(cof_Cover+1:cof_Cover+n_row,i);%y_Cover_temp = y_Cover(:,i);
  lambda_Cover = 0.011*norm(A_Cover_normalize'*y_Cover_temp,'inf');
    y_Cover_Recover_temp = lasso_my(A_Cover_normalize,y_Cover_temp,lambda_Cover,1,1.5);
  y_Cover_Recover_update(:,i) = y_Cover_Recover_temp;
end
x_Cover_Recover_combined = zeros(BlkSize_Cover,nBlk_Cover);
x_Cover_Recover_combined(order(cof_Cover+1:BlkSize_Cover),:) = y_Cover_Recover_update(1:n_col,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_Cover_Recover_combined(order(1:cof_Cover),:) = y_Cover_Recover_real(1:cof_Cover,:);%x_real(1:k1,:);    % not ebbedded signal
x_Cover_Recover = col2im(x_Cover_Recover_combined,[blk_Cover blk_Cover],[row_Cover col_Cover],'distinct');
x_Cover_Recover_Image_DCTCompressed = uint8(blkproc(x_Cover_Recover,[blk_Cover blk_Cover],fun2));
%figure,imshow(Cover_Image),title('Cover Image');
%figure,imshow(x_Cover_Recover_Image_DCTCompressed),title('Stego Image');
%figure,imhist(Cover_Image);title('Cover Image Histogram');
%figure,imhist(x_Cover_Recover_Image_DCTCompressed);title('Stego Image Histogram');
%PSNR_Cover_1hide_first = psnr(Cover_Image,x_Cover_Recover_Image_DCTCompressed,255);
%imwrite(x_Cover_Recover_Image_DCTCompressed,'StegoImage1.bmp');
%%%%%%%%% inverse sampling %%%%%%
[Cover_Image_r] = ImageInverseSampling(x_Cover_Recover_Image_DCTCompressed, CI2, CI3, CI4);

time_end_st1 = toc(time_start_st1);
%imwrite(Cover_Image_r,'StegoImage11.bmp');
%%%%%%%%%%% Stego-Image Performance %%%%%%%%%%
PSNR_Cover_1hide = psnr(Cover_Image_Original,Cover_Image_r,255);
NAE_Stego = NAE(Cover_Image_Original,Cover_Image_r);

%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
x_c=im2double(Cover_Image_Original);
x_reconstruct_c=im2double(Cover_Image_r);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+x_c(i,j)*x_reconstruct_c(i,j);
l2=l2+x_c(i,j)*x_c(i,j);
end
end
nc_stego=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=x_c;
img2c=x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_stego, ssim_map_stego] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%imshow(max(0, ssim_map).^4)  %Shows the SSIM index map
   %%% Entropy %%%
Entropy_cover=entropy(x_c);
Entropy_stego=entropy(x_reconstruct_c);

time_start_ex1 = tic;
%%%%% Recovery of secret Image from stego image
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Stego(:,i)=A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover

   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 

   Secret_recover_DC(2:temp1,i) = (1/beta)*(y_Stego_Reduced(cof_Cover-temp1+1:cof_Cover-1,i) - y_Stego_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i));%DC coefficient 

    temp = cof_Secret - 1; %temp = 15;
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);

 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Secret_Recover_Image_DCTcompressed=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Secret_Recover_Image_DCTcompressed,'Secret_Recover_Image_DCTcompressed_1.jpeg');

time_end_ex1 = toc(time_start_ex1);
% figure,imshow(Secret_Image_Resize),title('Secret Image');
% figure,imshow(Secret_Recover_Image_DCTcompressed),title('Secret Recovered Image');
% figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
% figure,imhist(Secret_Recover_Image_DCTcompressed);title('Secret Recovered Image Histogram');
NAE_Secret = NAE(Secret_Image_Resize,Secret_Recover_Image_DCTcompressed);

  BW1 = edge(Secret_Image_Resize,'sobel');
 imwrite(BW1, 'SecretEdgeMap.jpeg');
  BW2 = edge(Secret_Recover_Image_DCTcompressed,'sobel');
  imwrite(BW2, 'SecretRecoverEdgeMap.jpeg');
  %figure;imshow(BW1), title("Secret Image edge Map");
  %figure;imshow(BW2), title("Secret Recovered Image edge Map");
%%%%%%%%% Secret Image Recover from random matrix and wrong indices
   Noise_A_Cover_normalize = A_Cover_normalize;
   alpha = 1;
   beta = 1;
   gama = 1;
    
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    Noise_y_Stego(:,i)=Noise_A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; Noise_y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover
     temp1 = 1;
     temp2 = 2*temp1;
   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover - temp1,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 
    temp = cof_Secret - 1; 
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);
 %Secret_recover_DC(2:cof_Secret,i) = (1/beta) * (y_Cover_Reduced(t1:t2,i) - y_Cover_Reduced(cof_Cover+2:cof_Cover+cof_Secret,i));
 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Noise_Secret_Recover_Image_DCTcompressed=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Noise_Secret_Recover_Image_DCTcompressed,'Secret_Recover_Image_DCTcompressed_1_WrongKey.jpeg');

 %figure,imshow(Secret_Image_Resize),title('Secret Image');
 %figure,imshow(Noise_Secret_Recover_Image_DCTcompressed),title('Secret Recovered Image from wrong key');
 %figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
 %figure,imhist(Noise_Secret_Recover_Image_DCTcompressed);title('Secret Recovered Image Histogram from wrong key');
Noise_NAE_Secret = NAE(Secret_Image_Resize,Noise_Secret_Recover_Image_DCTcompressed);

%%%%%%%%%%%%%%%%%%%%%% Security Analysis between extracted secret image
%%%%%%%%%%%%%%%%%%%%%% from correct and wrong secret key
NAE_Secret_CorrVSWrong_1 = NAE(Secret_Recover_Image_DCTcompressed, Noise_Secret_Recover_Image_DCTcompressed);
PSNR_Secret_CorrVsWrong_1 = psnr(Secret_Recover_Image_DCTcompressed, Noise_Secret_Recover_Image_DCTcompressed,255);
%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
secret_x_c=im2double(Secret_Recover_Image_DCTcompressed);
secret_x_reconstruct_c=im2double(Noise_Secret_Recover_Image_DCTcompressed);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+secret_x_c(i,j)*secret_x_reconstruct_c(i,j);
l2=l2+secret_x_c(i,j)*secret_x_c(i,j);
end
end
nc_secret_1=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=secret_x_c;
img2c=secret_x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%[mssim_secret_1, ssim_map_secret_1] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_secret_1, ssim_map_secret_1] = ssim(Secret_Recover_Image_DCTcompressed,Noise_Secret_Recover_Image_DCTcompressed);
Entropy_secret_correc1=entropy(secret_x_c);
Entropy_secret_wrong1=entropy(secret_x_reconstruct_c);

time_start_em2 = tic;
%%%%%%% Second Image Embedding %%%%%%%%%%%%%%%%%%%%%%
Cover_Image = CI2; % 512x512
% block wise DCT on Cover Image
   J_Cover = blkproc(Cover_Image,[blk_Cover blk_Cover],fun1);
   x_Cover = im2col(J_Cover,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
   
   x_Cover_not_embed = x_Cover(order(1:cof_Cover),:);
   x_Cover_can_embed = x_Cover(order(cof_Cover+1:BlkSize_Cover),:);
   %%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Cover(:,i)=A_Cover_normalize*x_Cover_can_embed(:,i);
end

y_Cover_update = zeros(cof_Cover+n_row, nBlk_Cover); 
y_Cover_update = [x_Cover_not_embed; y_Cover];   % row wise concatenate

 %%%% Secret Image %%%%%
    Secret_Image_Resize=imread('Stream.tiff');
    [r1, c1, h1] = size(Secret_Image_Resize);
    if h1>1
        Secret_Image_Resize = Secret_Image_Resize(:,:,1);
    end
    Secret_Image_Resize = imresize(Secret_Image_Resize,[512 512]);
     [row_Secret,col_Secret]=size(Secret_Image_Resize);
    blk_Secret=8;
    nBlk_Secret=(row_Secret*col_Secret)/(blk_Secret*blk_Secret);
    BlkSize_Secret=blk_Secret*blk_Secret;
    J_Secret = blkproc(Secret_Image_Resize,[blk_Secret blk_Secret],fun1);
    x_Secret=im2col(J_Secret,[blk_Secret blk_Secret],'distinct');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Embedding of secret message----------
alpha = 0.01;%0.01
beta = 0.1;%0.01
gama = 1;
x_Secret_zig = x_Secret(order,:);
x_Secret_Reduced = x_Secret_zig(1:cof_Secret,:);
y_Cover_Reduced = y_Cover_update;
for i=1:nBlk_Cover
    temp1 = 6;  
    temp2 = 2*temp1;
    y_Cover_Reduced(cof_Cover,i)= y_Cover_Reduced(cof_Cover-temp2,i)+ alpha*x_Secret_Reduced(1,i);%DC coefficient

    y_Cover_Reduced(cof_Cover-temp1+1:cof_Cover-1,i)= y_Cover_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i)+ beta*x_Secret_Reduced(2:temp1,i); 
    temp = cof_Secret - 1; %temp = 15;
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp -(temp1 - 1);
   
   y_Cover_Reduced(t1:t2,i) = y_Cover_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i) + gama * x_Secret_Reduced((temp1-1)+2:cof_Secret,i);  
end

time_end_em2 = toc(time_start_em2);

time_start_st2 = tic;
%%%%%%%%% Stego Image Recover from samples %%%%%%%%
%%%%%separate  real coefficients and measurements from y_Cover_Reduced
y_Cover_Recover_real = y_Cover_Reduced(1:cof_Cover,:);       % 8 is size of ordr_not_embed
for i=1:(row_Cover*col_Cover)/(blk_Cover*blk_Cover)
  y_Cover_temp = y_Cover_Reduced(cof_Cover+1:cof_Cover+n_row,i);%y_Cover_temp = y_Cover(:,i);
  lambda_Cover = 0.011*norm(A_Cover_normalize'*y_Cover_temp,'inf');
    y_Cover_Recover_temp = lasso_my(A_Cover_normalize,y_Cover_temp,lambda_Cover,1,1.5);
       y_Cover_Recover_update(:,i) = y_Cover_Recover_temp;
end
x_Cover_Recover_combined = zeros(BlkSize_Cover,nBlk_Cover);
x_Cover_Recover_combined(order(cof_Cover+1:BlkSize_Cover),:) = y_Cover_Recover_update(1:n_col,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_Cover_Recover_combined(order(1:cof_Cover),:) = y_Cover_Recover_real(1:cof_Cover,:);%x_real(1:k1,:);    % not ebbedded signal
x_Cover_Recover = col2im(x_Cover_Recover_combined,[blk_Cover blk_Cover],[row_Cover col_Cover],'distinct');
x_Cover_Recover_Image_DCTCompressed_2 = uint8(blkproc(x_Cover_Recover,[blk_Cover blk_Cover],fun2));
%PSNR_Cover_2 = psnr(Cover_Image,x_Cover_Recover_Image_DCTCompressed_2,255);
%imwrite(x_Cover_Recover_Image_DCTCompressed_2,'StegoImage2.bmp');
%%%%%%%%% inverse sampling %%%%%%
[Cover_Image_r] = ImageInverseSampling(x_Cover_Recover_Image_DCTCompressed, x_Cover_Recover_Image_DCTCompressed_2, CI3, CI4);

time_end_st2 = toc(time_start_st2);
%imwrite(Cover_Image_r,'StegoImage22.bmp');
%%%%%%%%%%% Stego-Image Performance %%%%%%%%%%
PSNR_Cover_2hide = psnr(Cover_Image_Original,Cover_Image_r,255);
NAE_Stego_2hide = NAE(Cover_Image_Original,Cover_Image_r);

%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
x_c=im2double(Cover_Image_Original);
x_reconstruct_c=im2double(Cover_Image_r);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+x_c(i,j)*x_reconstruct_c(i,j);
l2=l2+x_c(i,j)*x_c(i,j);
end
end
nc_stego_2hide=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=x_c;
img2c=x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_stego_2hide, ssim_map_stego_2hide] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%imshow(max(0, ssim_map).^4)  %Shows the SSIM index map
   %%% Entropy %%%
Entropy_cover=entropy(x_c);
Entropy_stego_2hide=entropy(x_reconstruct_c);
 
time_start_ex2 = tic;
%%%%% Recovery of secret Image from stego image
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed_2,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Stego(:,i)=A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover

   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 

   Secret_recover_DC(2:temp1,i) = (1/beta)*(y_Stego_Reduced(cof_Cover-temp1+1:cof_Cover-1,i) - y_Stego_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i));%DC coefficient 

    temp = cof_Secret - 1;
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);

 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Secret_Recover_Image_DCTcompressed_2=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Secret_Recover_Image_DCTcompressed_2,'Secret_Recover_Image_DCTcompressed_2.jpeg');

time_end_ex2 = toc(time_start_ex2);
% figure,imshow(Secret_Image_Resize),title('Secret Image');
% figure,imshow(Secret_Recover_Image_DCTcompressed_2),title('Secret Recovered Image');
% figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
% figure,imhist(Secret_Recover_Image_DCTcompressed_2);title('Secret Recovered Image Histogram');
NAE_Secret_2 = NAE(Secret_Image_Resize,Secret_Recover_Image_DCTcompressed_2);

BW1 = edge(Secret_Image_Resize,'sobel');
 %imwrite(BW1, 'SecretEdgeMap.jpeg');
  BW2 = edge(Secret_Recover_Image_DCTcompressed_2,'sobel');
  %imwrite(BW1, 'SecretRecoverEdgeMap.jpeg');
  %figure;imshow(BW1), title("Secret Image edge Map");
  %figure;imshow(BW2), title("Secret Recovered Image edge Map");
%%%%%% For random Matrix and wrong indices and setttings
   Noise_A_Cover_normalize = A_Cover_normalize;
    alpha = 1;
   beta = 1;
   gama = 1;
   
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed_2,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    Noise_y_Stego(:,i)=Noise_A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; Noise_y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover
     temp1 = 1;
     temp2 = 2*temp1;
   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover - temp1,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 
    temp = cof_Secret - 1; 
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);
 %Secret_recover_DC(2:cof_Secret,i) = (1/beta) * (y_Cover_Reduced(t1:t2,i) - y_Cover_Reduced(cof_Cover+2:cof_Cover+cof_Secret,i));
 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Noise_Secret_Recover_Image_DCTcompressed_2=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Noise_Secret_Recover_Image_DCTcompressed_2,'Secret_Recover_Image_DCTcompressed_2_WrongKey.jpeg');

% figure,imshow(Secret_Image_Resize),title('Secret Image');
% figure,imshow(Noise_Secret_Recover_Image_DCTcompressed_2),title('Secret Recovered Image');
% figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
% figure,imhist(Noise_Secret_Recover_Image_DCTcompressed_2);title('Secret Recovered Image Histogram from wrong key');
Noise_NAE_Secret_2 = NAE(Secret_Image_Resize,Noise_Secret_Recover_Image_DCTcompressed_2);

%%%%%%%%%%%%%%%%%%%%%% Security Analysis between extracted secret image
%%%%%%%%%%%%%%%%%%%%%% from correct and wrong secret key
NAE_Secret_CorrVSWrong_2 = NAE(Secret_Recover_Image_DCTcompressed_2, Noise_Secret_Recover_Image_DCTcompressed_2);
PSNR_Secret_CorrVsWrong_2 = psnr(Secret_Recover_Image_DCTcompressed_2, Noise_Secret_Recover_Image_DCTcompressed_2,255);
%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
secret_x_c=im2double(Secret_Recover_Image_DCTcompressed_2);
secret_x_reconstruct_c=im2double(Noise_Secret_Recover_Image_DCTcompressed_2);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+secret_x_c(i,j)*secret_x_reconstruct_c(i,j);
l2=l2+secret_x_c(i,j)*secret_x_c(i,j);
end
end
nc_secret_2=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=secret_x_c;
img2c=secret_x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%[mssim_secret_2, ssim_map_secret_2] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_secret_2, ssim_map_secret_2] = ssim(Secret_Recover_Image_DCTcompressed_2,Noise_Secret_Recover_Image_DCTcompressed_2);
Entropy_secret_correc2 = entropy(secret_x_c);
Entropy_secret_wrong2 = entropy(secret_x_reconstruct_c);

time_start_em3 = tic;
%%%%%%% Third Image Embedding %%%%%%%%%%%%%%%%%%%%%%
Cover_Image = CI3; % 512x512
% block wise DCT on Cover Image
   J_Cover = blkproc(Cover_Image,[blk_Cover blk_Cover],fun1);
   x_Cover = im2col(J_Cover,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
   
   x_Cover_not_embed = x_Cover(order(1:cof_Cover),:);
   x_Cover_can_embed = x_Cover(order(cof_Cover+1:BlkSize_Cover),:);
  %%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Cover(:,i)=A_Cover_normalize*x_Cover_can_embed(:,i);
end
y_Cover_update = zeros(cof_Cover+n_row, nBlk_Cover); 
y_Cover_update = [x_Cover_not_embed; y_Cover];   % row wise concatenate

 %%%% Secret Image %%%%%
    Secret_Image_Resize=imread('peppers_gray.tif');
    [r1, c1, h1] = size(Secret_Image_Resize);
    if h1>1
        Secret_Image_Resize = Secret_Image_Resize(:,:,1);
    end
 Secret_Image_Resize = imresize(Secret_Image_Resize,[512 512]);
    [row_Secret,col_Secret]=size(Secret_Image_Resize);
    blk_Secret=8;
    nBlk_Secret=(row_Secret*col_Secret)/(blk_Secret*blk_Secret);
    BlkSize_Secret=blk_Secret*blk_Secret;
    J_Secret = blkproc(Secret_Image_Resize,[blk_Secret blk_Secret],fun1);
    x_Secret=im2col(J_Secret,[blk_Secret blk_Secret],'distinct');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Embedding of secret message----------
alpha = 0.01;%0.01
beta = 0.1;%0.01
gama = 1;
x_Secret_zig = x_Secret(order,:);
x_Secret_Reduced = x_Secret_zig(1:cof_Secret,:);
y_Cover_Reduced = y_Cover_update;
for i=1:nBlk_Cover
    temp1 = 6;  
    temp2 = 2*temp1;
    y_Cover_Reduced(cof_Cover,i)= y_Cover_Reduced(cof_Cover-temp2,i)+ alpha*x_Secret_Reduced(1,i);%DC coefficient

    y_Cover_Reduced(cof_Cover-temp1+1:cof_Cover-1,i)= y_Cover_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i)+ beta*x_Secret_Reduced(2:temp1,i); 
    temp = cof_Secret - 1; 
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp -(temp1 - 1);

   y_Cover_Reduced(t1:t2,i) = y_Cover_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i) + gama * x_Secret_Reduced((temp1-1)+2:cof_Secret,i);  
end

time_end_em3 = toc(time_start_em3);

time_start_st3 = tic;
%%%%%%%%% Stego Image from samples %%%%%%%%
%%%%%separate  real coefficients and measurements from y_Cover_Reduced
y_Cover_Recover_real = y_Cover_Reduced(1:cof_Cover,:);       % 8 is size of ordr_not_embed
for i=1:(row_Cover*col_Cover)/(blk_Cover*blk_Cover)
  y_Cover_temp = y_Cover_Reduced(cof_Cover+1:cof_Cover+n_row,i);%y_Cover_temp = y_Cover(:,i);
  lambda_Cover = 0.011*norm(A_Cover_normalize'*y_Cover_temp,'inf');
   y_Cover_Recover_temp = lasso_my(A_Cover_normalize,y_Cover_temp,lambda_Cover,1,1.5);
  y_Cover_Recover_update(:,i) = y_Cover_Recover_temp;
end
x_Cover_Recover_combined = zeros(BlkSize_Cover,nBlk_Cover);
x_Cover_Recover_combined(order(cof_Cover+1:BlkSize_Cover),:) = y_Cover_Recover_update(1:n_col,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_Cover_Recover_combined(order(1:cof_Cover),:) = y_Cover_Recover_real(1:cof_Cover,:);%x_real(1:k1,:);    % not ebbedded signal
x_Cover_Recover = col2im(x_Cover_Recover_combined,[blk_Cover blk_Cover],[row_Cover col_Cover],'distinct');
x_Cover_Recover_Image_DCTCompressed_3 = uint8(blkproc(x_Cover_Recover,[blk_Cover blk_Cover],fun2));
%PSNR_Cover_3 = psnr(Cover_Image,x_Cover_Recover_Image_DCTCompressed_3,255);
%imwrite(x_Cover_Recover_Image_DCTCompressed_3,'StegoImage3.bmp');
%%%%%%%%% inverse sampling %%%%%%
[Cover_Image_r] = ImageInverseSampling(x_Cover_Recover_Image_DCTCompressed, x_Cover_Recover_Image_DCTCompressed_2, x_Cover_Recover_Image_DCTCompressed_3, CI4);

time_end_st3 = toc(time_start_st3);
%imwrite(Cover_Image_r,'StegoImage33.bmp');
%%%%%%%%%%% Stego-Image Performance %%%%%%%%%%
PSNR_Cover_3hide = psnr(Cover_Image_Original,Cover_Image_r,255);
NAE_Stego_3hide = NAE(Cover_Image_Original,Cover_Image_r);

%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
x_c=im2double(Cover_Image_Original);
x_reconstruct_c=im2double(Cover_Image_r);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+x_c(i,j)*x_reconstruct_c(i,j);
l2=l2+x_c(i,j)*x_c(i,j);
end
end
nc_stego_3hide=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=x_c;
img2c=x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_stego_3hide, ssim_map_stego_3hide] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%imshow(max(0, ssim_map).^4)  %Shows the SSIM index map
   %%% Entropy %%%
Entropy_cover=entropy(x_c);
Entropy_stego_3hide=entropy(x_reconstruct_c);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
time_start_ex3 = tic;
%%%%% Recovery of secret Image from stego image
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed_3,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Stego(:,i)=A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover
   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 

   Secret_recover_DC(2:temp1,i) = (1/beta)*(y_Stego_Reduced(cof_Cover-temp1+1:cof_Cover-1,i) - y_Stego_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i));%DC coefficient 
    temp = - 1; 
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);

 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Secret_Recover_Image_DCTcompressed_3=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Secret_Recover_Image_DCTcompressed_3,'Secret_Recover_Image_DCTcompressed_3.jpeg');

time_end_ex3 = toc(time_start_ex3);

  %figure,imshow(Secret_Image_Resize),title('Secret Image');
  %figure,imshow(Secret_Recover_Image_DCTcompressed_3),title('Secret Recovered Image');
  %figure,imhist(Secret_Image_Resize);title('Secret 3rd Image Histogram');
  %figure,imhist(Secret_Recover_Image_DCTcompressed_3);title('Secret Recovered 3rd Image Histogram');
 NAE_Secret_3 = NAE(Secret_Image_Resize,Secret_Recover_Image_DCTcompressed_3);
% title('Sobel Filter');
 BW1 = edge(Secret_Image_Resize,'sobel');
 imwrite(BW1, 'SecretEdgeMap.jpeg');
  BW2 = edge(Secret_Recover_Image_DCTcompressed_3,'sobel');
  imwrite(BW1, 'SecretRecoverEdgeMap.jpeg');
 % figure;imshow(BW1), title("Secret Image edge Map");
  %figure;imshow(BW2), title("Secret Recovered Image edge Map");
  
%%%%%% For random MAtrix and wrong indices
   Noise_A_Cover_normalize = A_Cover_normalize;
   alpha = 1;
   beta = 1;
   gama = 1;
    
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed_3,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    Noise_y_Stego(:,i)=Noise_A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; Noise_y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover
      temp1 = 1;
     temp2 = 2*temp1;
   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover - temp1,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 
    temp = cof_Secret - 1; 
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);
 %Secret_recover_DC(2:cof_Secret,i) = (1/beta) * (y_Cover_Reduced(t1:t2,i) - y_Cover_Reduced(cof_Cover+2:cof_Cover+cof_Secret,i));
 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Noise_Secret_Recover_Image_DCTcompressed_3=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Noise_Secret_Recover_Image_DCTcompressed_3,'Secret_Recover_Image_DCTcompressed_3_WrongKey.jpeg');
%  figure,imshow(Secret_Image_Resize),title('Secret Image');
%  figure,imshow(Noise_Secret_Recover_Image_DCTcompressed_3),title('Secret Recovered Image');
%  figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
%  figure,imhist(Noise_Secret_Recover_Image_DCTcompressed_3);title('Secret Recovered Image Histogram');
Noise_NAE_Secret_3 = NAE(Secret_Image_Resize,Noise_Secret_Recover_Image_DCTcompressed_3);
% TAF_Secret_2 = TAF(Secret_Image_Resize,Secret_Recover_Image_DCTcompressed_2);

%%%%%%%%%%%%%%%%%%%%%% Security Analysis between extracted secret image
%%%%%%%%%%%%%%%%%%%%%% from correct and wrong secret key
NAE_Secret_CorrVSWrong_3 = NAE(Secret_Recover_Image_DCTcompressed_3, Noise_Secret_Recover_Image_DCTcompressed_3);
PSNR_Secret_CorrVsWrong_3 = psnr(Secret_Recover_Image_DCTcompressed_3, Noise_Secret_Recover_Image_DCTcompressed_3,255);
%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
secret_x_c=im2double(Secret_Recover_Image_DCTcompressed_3);
secret_x_reconstruct_c=im2double(Noise_Secret_Recover_Image_DCTcompressed_3);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+secret_x_c(i,j)*secret_x_reconstruct_c(i,j);
l2=l2+secret_x_c(i,j)*secret_x_c(i,j);
end
end
nc_secret_3=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=secret_x_c;
img2c=secret_x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%[mssim_secret_3, ssim_map_secret_3] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_secret_3, ssim_map_secret_3] = ssim(Secret_Recover_Image_DCTcompressed_3,Noise_Secret_Recover_Image_DCTcompressed_3);
Entropy_secret_correc3 = entropy(secret_x_c);
Entropy_secret_wrong3 = entropy(secret_x_reconstruct_c);

time_start_em4 = tic;
%%%%%%%  FourthImage Embedding %%%%%%%%%%%%%%%%%%%%%%
Cover_Image = CI4; % 512x512
% block wise DCT on Cover Image
   J_Cover = blkproc(Cover_Image,[blk_Cover blk_Cover],fun1);
   x_Cover = im2col(J_Cover,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
   
   x_Cover_not_embed = x_Cover(order(1:cof_Cover),:);
   x_Cover_can_embed = x_Cover(order(cof_Cover+1:BlkSize_Cover),:);
  
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Cover(:,i)=A_Cover_normalize*x_Cover_can_embed(:,i);
end
y_Cover_update = zeros(cof_Cover+n_row, nBlk_Cover); 
y_Cover_update = [x_Cover_not_embed; y_Cover];   % row wise concatenate

 %%%% Secret Image %%%%%
    Secret_Image_Resize=imread('cameraman.tif');
    [r1, c1, h1] = size(Secret_Image_Resize);
    if h1>1
        Secret_Image_Resize = Secret_Image_Resize(:,:,1);
    end
Secret_Image_Resize = imresize(Secret_Image_Resize,[512 512]);
    [row_Secret,col_Secret]=size(Secret_Image_Resize);
    blk_Secret=8;
    nBlk_Secret=(row_Secret*col_Secret)/(blk_Secret*blk_Secret);
    BlkSize_Secret=blk_Secret*blk_Secret;
    J_Secret = blkproc(Secret_Image_Resize,[blk_Secret blk_Secret],fun1);
    x_Secret=im2col(J_Secret,[blk_Secret blk_Secret],'distinct');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
% Embedding of secret message----------
alpha = 0.01;%0.01
beta = 0.1;%0.01
gama = 1;
x_Secret_zig = x_Secret(order,:);
x_Secret_Reduced = x_Secret_zig(1:cof_Secret,:);
y_Cover_Reduced = y_Cover_update;
for i=1:nBlk_Cover
    temp1 = 6;  
    temp2 = 2*temp1;
    y_Cover_Reduced(cof_Cover,i)= y_Cover_Reduced(cof_Cover-temp2,i)+ alpha*x_Secret_Reduced(1,i);%DC coefficient

    y_Cover_Reduced(cof_Cover-temp1+1:cof_Cover-1,i)= y_Cover_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i)+ beta*x_Secret_Reduced(2:temp1,i); 
    temp = cof_Secret - 1; %temp = 15;
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp -(temp1 - 1);

   y_Cover_Reduced(t1:t2,i) = y_Cover_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i) + gama * x_Secret_Reduced((temp1-1)+2:cof_Secret,i);  
end
time_end_em4 = toc(time_start_em4);

time_start_st4 = tic;
%%%%%%%%% Cover Image Recover from samples %%%%%%%%
%%%%%separate  real coefficients and measurements from y_Cover_Reduced
y_Cover_Recover_real = y_Cover_Reduced(1:cof_Cover,:);       % 8 is size of ordr_not_embed
for i=1:(row_Cover*col_Cover)/(blk_Cover*blk_Cover)
  y_Cover_temp = y_Cover_Reduced(cof_Cover+1:cof_Cover+n_row,i);%y_Cover_temp = y_Cover(:,i);
  lambda_Cover = 0.011*norm(A_Cover_normalize'*y_Cover_temp,'inf');
  y_Cover_Recover_temp = lasso_my(A_Cover_normalize,y_Cover_temp,lambda_Cover,1,1.5);
  y_Cover_Recover_update(:,i) = y_Cover_Recover_temp;
end
x_Cover_Recover_combined = zeros(BlkSize_Cover,nBlk_Cover);
x_Cover_Recover_combined(order(cof_Cover+1:BlkSize_Cover),:) = y_Cover_Recover_update(1:n_col,:);  % n is size of recovered signal/origina signal in which we performed compressed sensong
x_Cover_Recover_combined(order(1:cof_Cover),:) = y_Cover_Recover_real(1:cof_Cover,:);%x_real(1:k1,:);    % not ebbedded signal
x_Cover_Recover = col2im(x_Cover_Recover_combined,[blk_Cover blk_Cover],[row_Cover col_Cover],'distinct');
x_Cover_Recover_Image_DCTCompressed_4 = uint8(blkproc(x_Cover_Recover,[blk_Cover blk_Cover],fun2));
%PSNR_Cover_4 = psnr(Cover_Image,x_Cover_Recover_Image_DCTCompressed_4,255);
%imwrite(x_Cover_Recover_Image_DCTCompressed_4,'StegoImage4.bmp');
%%%%%%%%% inverse sampling %%%%%%
[Cover_Image_r] = ImageInverseSampling(x_Cover_Recover_Image_DCTCompressed, x_Cover_Recover_Image_DCTCompressed_2, x_Cover_Recover_Image_DCTCompressed_3, x_Cover_Recover_Image_DCTCompressed_4);

time_end_st4 = toc(time_start_st4);

imwrite(Cover_Image_r,'StegoImage44.bmp');
%figure,imhist(Cover_Image_Original);title('Cover Image Histogram');
%figure,imhist(Cover_Image_r);title('Stego Image Histogram');

save fn_proposed Cover_Image_r;
%%%%%%%%%%% Stego-Image Performance %%%%%%%%%%
PSNR_Cover_4hide = psnr(Cover_Image_Original,Cover_Image_r,255);
NAE_Stego_4hide = NAE(Cover_Image_Original,Cover_Image_r);

%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
x_c=im2double(Cover_Image_Original);
x_reconstruct_c=im2double(Cover_Image_r);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+x_c(i,j)*x_reconstruct_c(i,j);
l2=l2+x_c(i,j)*x_c(i,j);
end
end
nc_stego_4hide=l1/l2;
%nc=min(l1/l2,l2/l1);
 %%% SSIM matching %%%%%%%%%%%%%%
img1c=x_c;
img2c=x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_stego_4hide, ssim_map_stego_4hide] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%imshow(max(0, ssim_map).^4)  %Shows the SSIM index map
 %%% Entropy %%%
Entropy_cover=entropy(x_c);
Entropy_stego_4hide=entropy(x_reconstruct_c);

%%%%%%%%%% Image Map checking %%%%%%%%%
%%% Sobel edge detetor %%%%%%
 BW1 = edge(Cover_Image_Original,'sobel');
 BW2 = edge(Cover_Image_r,'sobel');
 %figure; imshow(BW1), title("Cover Image Edge Map");
 imwrite(BW1, 'CoverEdgeMap.jpeg');
 %figure; imshow(BW2), title("Stego Image Edge Map");
 imwrite(BW2, 'StegoEdgeMap.jpeg')
% imshowpair(BW1,BW2,'montage');

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
time_start_ex4 = tic;
%%%%% Recovery of secret Image from stego image
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed_4,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    y_Stego(:,i)=A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover
   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 

   Secret_recover_DC(2:temp1,i) = (1/beta)*(y_Stego_Reduced(cof_Cover-temp1+1:cof_Cover-1,i) - y_Stego_Reduced((cof_Cover-temp2+1):(cof_Cover-temp1-1),i));%DC coefficient 

    temp = cof_Secret - 1; 
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);

 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Secret_Recover_Image_DCTcompressed_4=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Secret_Recover_Image_DCTcompressed_4,'Secret_Recover_Image_DCTcompressed_4.jpeg');

time_end_ex4 = toc(time_start_ex4);
%  figure,imshow(Secret_Image_Resize),title('Secret Image');
%  figure,imshow(Secret_Recover_Image_DCTcompressed_4),title('Secret Recovered Image');
%  figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
%  figure,imhist(Secret_Recover_Image_DCTcompressed_4);title('Secret Recovered Image Histogram');
 NAE_Secret_4 = NAE(Secret_Image_Resize,Secret_Recover_Image_DCTcompressed_4);

 BW1 = edge(Secret_Image_Resize,'sobel');
 %imwrite(BW1, 'SecretEdgeMap.jpeg');
  BW2 = edge(Secret_Recover_Image_DCTcompressed_4,'sobel');
  %imwrite(BW1, 'SecretRecoverEdgeMap.jpeg');
  %figure;imshow(BW1), title("Secret Image edge Map");
  %figure;imshow(BW2), title("Secret Recovered Image edge Map");
  
%%%%%% For random MAtrix and wrong indices
   Noise_A_Cover_normalize = A_Cover_normalize;
   alpha = 1;
   beta = 1;
   gama = 1;
    
J_Stego = blkproc(x_Cover_Recover_Image_DCTCompressed_4,[blk_Cover blk_Cover],fun1);
x_Stego=im2col(J_Stego,[blk_Cover blk_Cover],'distinct');  % taking blk x blk matrix as column.....
x_Stego_not_embed = x_Stego(order(1:cof_Cover),:);
x_Stego_can_embed = x_Stego(order(cof_Cover+1:BlkSize_Cover),:);
%%%% fiinding measurements y=A*x
for i=1:nBlk_Cover
    Noise_y_Stego(:,i)=Noise_A_Cover_normalize*x_Stego_can_embed(:,i);%x1_can_embed(:,i);
end
y_Stego_update = zeros(cof_Cover + n_row, nBlk_Cover); % k1 is size of order_not_embed
y_Stego_update = [x_Stego_not_embed; Noise_y_Stego];   % row wise concatenate
y_Stego_Reduced = y_Stego_update;

Secret_recover_DC = zeros(BlkSize_Secret,nBlk_Secret);
for i=1:nBlk_Cover
      temp1 = 1;
     temp2 = 2*temp1;
   Secret_recover_DC(1,i) = (1/alpha)*(y_Stego_Reduced(cof_Cover - temp1,i) - y_Stego_Reduced(cof_Cover-temp2,i));%DC coefficient 
 temp = cof_Secret - 1; %temp = 15;
    t1 = cof_Cover + 2 + temp;
    t2 = cof_Cover + cof_Secret + temp - (temp1 - 1);
 %Secret_recover_DC(2:cof_Secret,i) = (1/beta) * (y_Cover_Reduced(t1:t2,i) - y_Cover_Reduced(cof_Cover+2:cof_Cover+cof_Secret,i));
 Secret_recover_DC((temp1-1)+2:cof_Secret,i) = (1/gama) * (y_Stego_Reduced(t1:t2,i) - y_Stego_Reduced(cof_Cover+2+(temp1-1):cof_Cover+cof_Secret,i));
end
x_Secret_Recover_zig(order,:) = Secret_recover_DC;
x_Secret_Recover = col2im(x_Secret_Recover_zig,[blk_Secret blk_Secret],[row_Secret col_Secret],'distinct');
Noise_Secret_Recover_Image_DCTcompressed_4=uint8(blkproc(x_Secret_Recover,[blk_Secret blk_Secret],fun2));
imwrite(Noise_Secret_Recover_Image_DCTcompressed_4,'Secret_Recover_Image_DCTcompressed_4_WrongKey.jpeg');

%  figure,imshow(Secret_Image_Resize),title('Secret Image');
%  figure,imshow(Noise_Secret_Recover_Image_DCTcompressed_4),title('Secret Recovered Image');
%  figure,imhist(Secret_Image_Resize);title('Secret Image Histogram');
%  figure,imhist(Noise_Secret_Recover_Image_DCTcompressed_4);title('Secret Recovered Image Histogram');
Noise_NAE_Secret_4 = NAE(Secret_Image_Resize,Noise_Secret_Recover_Image_DCTcompressed_4);

%%%%%%%%%%%%%%%%%%%%%% Security Analysis between extracted secret image
%%%%%%%%%%%%%%%%%%%%%% from correct and wrong secret key
NAE_Secret_CorrVSWrong_4 = NAE(Secret_Recover_Image_DCTcompressed_4, Noise_Secret_Recover_Image_DCTcompressed_4);
PSNR_Secret_CorrVsWrong_4 = psnr(Secret_Recover_Image_DCTcompressed_4, Noise_Secret_Recover_Image_DCTcompressed_4,255);
%%%%%% findind normalized corelation %
%nc=normalized_corelation(x,x_reconstruct);
%function [nc]=normalized_corelation(x,x_reconstruct)
secret_x_c=im2double(Secret_Recover_Image_DCTcompressed_4);
secret_x_reconstruct_c=im2double(Noise_Secret_Recover_Image_DCTcompressed_4);
l1=0;
l2=0;
for i=1:512
for j=1:512
l1=l1+secret_x_c(i,j)*secret_x_reconstruct_c(i,j);
l2=l2+secret_x_c(i,j)*secret_x_c(i,j);
end
end
nc_secret_4=l1/l2;
%nc=min(l1/l2,l2/l1);
    %%% SSIM matching %%%%%%%%%%%%%%
img1c=secret_x_c;
img2c=secret_x_reconstruct_c;
%[mssim, ssim_map] = ssim_index(img1, img2);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
%[mssim_secret_4, ssim_map_secret_4] = ssim(img1c, img2c);       %%%% L = 255 default in ssim_index.m and mssim is mean ssim
[mssim_secret_4, ssim_map_secret_4] = ssim(Secret_Recover_Image_DCTcompressed_4,Noise_Secret_Recover_Image_DCTcompressed_4);
Entropy_secret_correc4 = entropy(secret_x_c);
Entropy_secret_wrong4 = entropy(secret_x_reconstruct_c);

total_time_em = time_end_em1 + time_end_em2 + time_end_em3 + time_end_em4; 
total_time_st = time_end_st1 + time_end_st2 + time_end_st3 + time_end_st4;
total_time_ex = time_end_ex1 + time_end_ex2 + time_end_ex3 + time_end_ex4;
%toc;
