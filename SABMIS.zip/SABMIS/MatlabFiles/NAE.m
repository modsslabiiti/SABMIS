%% Normalized absolute error
function [N]=NAE(w,wex)

% w     = Cover Image
% wex   = REconstructed Cover Image
% T     = TAF result
% Code Developed BY : Suraj Kamya
% kamyasuraj@yahoo.com
[r c]=size(w); % Size of wmrk
 
Abs_Error = abs(w-wex);
N = sum(Abs_Error(:))/sum(abs(w(:)));
