function [CI1, CI2, CI3, CI4] = ImageSampling(Cover_Image)
%Cover_Image=imread('Lena.bmp');
[r,c,~]=size(Cover_Image);

for i=1:r/2
for j=1:c/2
CI1(i,j) = Cover_Image(2*i-1,2*j-1);
CI2(i,j) = Cover_Image(2*i,2*j-1);
CI3(i,j) = Cover_Image(2*i-1,2*j);
CI4(i,j) = Cover_Image(2*i,2*j);
end
end
%figure;imshow(CI1);
%figure;imshow(CI2);
%figure;imshow(CI3);
%figure;imshow(CI4);
%imwrite(CI1,'Lena1.bmp');
%imwrite(CI2,'Lena2.bmp');
%imwrite(CI3,'Lena3.bmp');
%imwrite(CI4,'Lena4.bmp');
end
