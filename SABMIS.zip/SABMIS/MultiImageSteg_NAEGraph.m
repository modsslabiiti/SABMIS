%%%%%%%%%%% NAE values Graph %%%%%%%

x = categorical({'Cars','Peppers', 'Boat', 'House', 'Lake', 'Stream', 'Living room', 'Tank', 'Jetplane', 'Camera man'});
x = reordercats(x,{'Cars','Peppers', 'Boat', 'House', 'Lake', 'Stream', 'Living room', 'Tank', 'Jetplane', 'Camera man'});
NAE_WrongKey = [0.9952 0.9956 0.9952 0.9970 0.9964 0.9908 0.9946 0.9947 0.9952 0.9962];
NAE_RightKey = [0.0532 0.0495 0.0526 0.0527 0.0523 0.0578 0.0551 0.0528 0.0527 0.0549];
plot(x,NAE_RightKey,'b--*',x,NAE_WrongKey,'r--o');
xlabel('Cover Image Used for Embedding', 'fontweight','bold', 'FontSize',12); 
ylabel('Average NAE Values', 'fontweight','bold', 'FontSize',12);
legend({'Using correct secret-keys','Using wrong secret-keys'},'Location','southwest', 'fontweight','bold', 'FontSize',11);

%%%%%%%%%%%%%%%%%%%%%%%%%


