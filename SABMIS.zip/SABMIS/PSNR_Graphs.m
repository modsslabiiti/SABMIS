%%%%%%%%%%% PSNR values Graph %%%%%%%
%%%%%%%%%%%%% 1 image is hidden
x = categorical({'Cars','Peppers', 'Boat', 'House', 'Lake', 'Stream', 'Living room', 'Tank', 'Jetplane', 'Camera man'});
x = reordercats(x,{'Cars','Peppers', 'Boat', 'House', 'Lake', 'Stream', 'Living room', 'Tank', 'Jetplane', 'Camera man'});
PSNR_PepperHide = [43.7 43 41.63 46.25 41.39 37.96 40.65 42.78 41.99 44.24];
PSNR_LakeHide = [42.72 42.16 41 44.56 40.8 37.67 40.1 42 41.33 43.16];
PSNR_StreamHide = [43.15 41.94 40.67 44.23 40.65 37.66 39.91 41.84 41.3 43.08];
PSNR_CaremamanHide = [43.43 42.67 41.41 45.78 41.19 37.86 40.45 42.56 41.77 44.2];
plot(x,PSNR_PepperHide,'b--*',x,PSNR_LakeHide,'r--o', x, PSNR_StreamHide, 'g--^', x, PSNR_CaremamanHide, 'c--+');
xlabel('Images', 'fontweight','bold', 'FontSize',12); 
ylabel('PSNR Values', 'fontweight','bold', 'FontSize',12);
legend({'Peppers secret image is hidden','Lake secret image is hidden', 'Stream secret image is hidden', 'Cameraman secret image is hidden'},'Location','southwest', 'fontweight','bold', 'FontSize',11);

%%%%%%%%%%%%%%%%%%%%%%%%%1 to 4 images are hidden
x = categorical({'Cars','Peppers', 'Boat', 'House', 'Lake', 'Stream', 'Living room', 'Tank', 'Jetplane', 'Camera man'});
x = reordercats(x,{'Cars','Peppers', 'Boat', 'House', 'Lake', 'Stream', 'Living room', 'Tank', 'Jetplane', 'Camera man'});
PSNR_1Hide = [43.25 42.44 41.24 45.21 41.01 37.79 40.28 42.30 41.60 43.67];
PSNR_2Hide = [40.31 39.25 38.34 42.34 38.01 34.81 37.42 39.40 38.82 40.74];
PSNR_3Hide = [38.55 37.60 36.67 40.80 36.35 33.09 36.01 37.81 37.05 39.21];
PSNR_4Hide = [37.35 36.22 35.06 39.28 35.02 31.78 34.42 36.54 35.75 37.80];
plot(x,PSNR_1Hide,'b--*',x,PSNR_2Hide,'r--o', x, PSNR_3Hide, 'g--^', x, PSNR_4Hide, 'c--+');
xlabel('Images', 'fontweight','bold', 'FontSize',12); 
ylabel('PSNR Values', 'fontweight','bold', 'FontSize',12);
legend({'1 secret image is hidden','2 secret images are hidden', '3 secret images are hidden', '4 secret images are hidden'},'Location','southwest', 'fontweight','bold', 'FontSize',11);
