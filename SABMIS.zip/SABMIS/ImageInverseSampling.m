function [Cover_Image_r] = ImageInverseSampling(Cover_Image1, Cover_Image2, Cover_Image3, Cover_Image4)
%Cover_Image1=imread('Lena1.bmp');
%Cover_Image2=imread('Lena2.bmp');
%Cover_Image3=imread('Lena3.bmp');
%Cover_Image4=imread('Lena4.bmp');
[r,c,~]=size(Cover_Image1);
for i=1:r
for j=1:c
Cover_Image_r(2*i-1,2*j-1) = Cover_Image1(i,j);
Cover_Image_r(2*i,2*j-1) = Cover_Image2(i,j);
Cover_Image_r(2*i-1,2*j) = Cover_Image3(i,j);
Cover_Image_r(2*i,2*j) = Cover_Image4(i,j);
end
end
%figure;imshow(Cover_Image_r);
%Cover_Image=imread('Lena.bmp');
%psnr(Cover_Image,Cover_Image_r,255);
end
