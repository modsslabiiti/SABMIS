%% Normalized absolute error
function [NAE_Values]=NAE(I1,I2)
[r c]=size(I1); % Size of the image 
Abs_Error = abs(I1-I2);
NAE_Values = sum(Abs_Error(:))/sum(abs(I1(:)));
